# Creates the master encryption key

ALTER SYSTEM SET ENCRYPTION KEY IDENTIFIED BY "welcome1";